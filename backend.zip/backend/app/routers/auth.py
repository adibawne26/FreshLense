from fastapi import APIRouter, HTTPException, status, Depends, BackgroundTasks
from datetime import datetime, timedelta
import secrets
import os
import logging
from typing import Optional, Dict, Any

from ..database import (
    get_user_by_email, 
    create_user,
    create_password_reset_token,
    get_valid_password_reset_token,
    mark_password_reset_token_used,
    update_user_password,
    update_user_mfa_status,
    update_user_mfa_code,
    clear_user_mfa_code,
    get_user_mfa_status,
    get_db,
    update_user_mfa_session  # Add this new database function
)
from ..schemas.auth import (
    ForgotPasswordRequest, 
    ResetPasswordRequest, 
    ForgotPasswordResponse, 
    ResetPasswordResponse,
    MFASetupRequest,
    MFAVerifyRequest,
    MFALoginResponse,
    User,
    UserCreate,
    UserLogin,
    MFASessionCheckRequest  # Add this new schema
)
from ..services.mfa_service import mfa_service
from ..services.email_service import send_mfa_email, send_mfa_setup_email, send_reset_email

# Import your JWT utilities
from ..utils.security import (
    create_access_token,
    verify_password,
    get_password_hash,
    get_token_expiry_info,
    is_token_valid,
    decode_access_token
)

router = APIRouter(prefix="/api/auth", tags=["authentication"])
logger = logging.getLogger(__name__)

# ================================================
# ✅ CORS Preflight Handlers - NO AUTHENTICATION REQUIRED
# ================================================

@router.options("/{rest_of_path:path}")
@router.options("/debug-token-test")
@router.options("/validate-token")
@router.options("/register")
@router.options("/login")
@router.options("/send-mfa-code")
@router.options("/verify-mfa")
@router.options("/forgot-password")
@router.options("/reset-password")
@router.options("/setup-mfa")
@router.options("/disable-mfa")
@router.options("/mfa-status")
@router.options("/check-mfa-session")
async def options_handler():
    """Handle OPTIONS preflight requests without authentication"""
    return {}

# -------------------------------
# DEBUG ENDPOINT - ADD THIS FIRST
# -------------------------------
@router.post("/debug-token-test")
async def debug_token_test():
    """Debug endpoint to test token creation"""
    # Create a test token
    test_token = create_access_token(data={"sub": "debug@test.com"})
    
    # Get token info
    token_info = get_token_expiry_info(test_token)
    
    # Decode to see payload
    try:
        payload = decode_access_token(test_token)
    except:
        payload = {"error": "Cannot decode"}
    
    return {
        "token_created": True,
        "token_preview": test_token[:50] + "..." if len(test_token) > 50 else test_token,
        "token_info": token_info,
        "payload": payload,
        "server_time_utc": datetime.utcnow().isoformat(),
        "access_token_expire_minutes": 1440
    }

# -------------------------------
# TOKEN VALIDATION ENDPOINT
# -------------------------------
@router.post("/validate-token")
async def validate_token(token: Dict[str, str]):
    """
    Validate if a token is still valid.
    """
    token_str = token.get("token")
    if not token_str:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Token is required"
        )
    
    # Check if token is valid
    if is_token_valid(token_str):
        token_info = get_token_expiry_info(token_str)
        logger.debug(f"Token validated for subject: {token_info.get('subject')}")
        return {
            "valid": True,
            "message": "Token is valid",
            "expires_at": token_info.get("expires_at"),
            "time_remaining_seconds": token_info.get("time_remaining_seconds"),
            "subject": token_info.get("subject")
        }
    else:
        logger.warning(f"Invalid or expired token received")
        return {
            "valid": False,
            "message": "Token is invalid or expired",
            "expires_at": None,
            "time_remaining_seconds": 0
        }

# -------------------------------
# Registration Endpoint - UPDATED (No MFA, just success message)
# -------------------------------
@router.post("/register")
async def register(user_data: UserCreate):
    """
    Register a new user. MFA is disabled by default.
    User will need to go through MFA during login.
    """
    # Check if user already exists
    existing_user = get_user_by_email(user_data.email)
    if existing_user:
        logger.warning(f"Registration attempted for existing email: {user_data.email}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # ✅ Create user WITH MFA DISABLED BY DEFAULT
    user = create_user({
        "email": user_data.email,
        "password": user_data.password,
        "mfa_enabled": False,
        "mfa_email": user_data.email,
        "mfa_setup_completed": False,
        "mfa_verified_at": None,  # Track when MFA was last verified
        "mfa_session_token": None  # Track MFA session token
    })
    
    if not user:
        logger.error(f"Failed to create user: {user_data.email}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create user"
        )
    
    logger.info(f"New user registered: {user['email']}")
    
    # ✅ Return success message (NO token, NO MFA code)
    return {
        "message": "Registration successful! Please login to continue.",
        "email": user["email"]
    }

# -------------------------------
# Login Endpoint - UPDATED with BackgroundTasks
# -------------------------------
@router.post("/login")
async def login(user_credentials: UserLogin, background_tasks: BackgroundTasks):
    """
    User login - ALWAYS requires MFA for all users.
    MFA code will be sent to user's email in the background.
    """
    # Get user from database
    user = get_user_by_email(user_credentials.email)
    
    if not user:
        # Return generic error for security
        logger.warning(f"Login attempt for non-existent user: {user_credentials.email}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Verify password
    if not verify_password(user_credentials.password, user["hashed_password"]):
        logger.warning(f"Invalid password for user: {user['email']}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Check if MFA session is still valid (within 24 hours)
    mfa_verified_at = user.get("mfa_verified_at")
    if mfa_verified_at:
        # Convert string to datetime if needed
        if isinstance(mfa_verified_at, str):
            try:
                mfa_verified_at = datetime.fromisoformat(mfa_verified_at.replace('Z', '+00:00'))
            except ValueError:
                mfa_verified_at = None
        
        # Check if within 24 hours
        if mfa_verified_at and (datetime.utcnow() - mfa_verified_at) < timedelta(hours=24):
            # MFA session is still valid, create token directly
            access_token = create_access_token(data={"sub": user["email"]})
            logger.info(f"User {user['email']} logged in using valid MFA session")
            return {
                "access_token": access_token,
                "token_type": "bearer",
                "email": user["email"],
                "message": "Login successful (MFA session valid)"
            }
    
    # Require MFA - Send code in background (doesn't block response)
    logger.debug(f"MFA required for user: {user['email']}")
    
    # Send MFA code in background - THIS IS THE FIX
    background_tasks.add_task(send_mfa_code_to_user, user)
    
    # ✅ Return MFA required response immediately (email sends in background)
    return {
        "requires_mfa": True,
        "email": user["email"],
        "message": "MFA code being sent to your email"
    }

# -------------------------------
# Send MFA Code Endpoint - UPDATED with BackgroundTasks
# -------------------------------
@router.post("/send-mfa-code")
async def send_mfa_code(request: Dict[str, str], background_tasks: BackgroundTasks):
    """
    Send MFA code to user's email in the background.
    Can be used for login or during MFA setup.
    """
    email = request.get("email")
    if not email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is required"
        )
    
    user = get_user_by_email(email)
    if not user:
        # Return success even if user doesn't exist for security
        logger.debug(f"MFA code requested for non-existent user: {email}")
        return {"message": "If the email exists, a verification code has been sent"}
    
    # Send MFA code in background - THIS IS THE FIX
    background_tasks.add_task(send_mfa_code_to_user, user)
    
    return {"message": "MFA code being sent to your email"}

@router.post("/verify-mfa")
async def verify_mfa_code(request: MFAVerifyRequest):
    """
    Verify MFA code and return access token.
    Supports "Remember Me for 24 hours" feature.
    """
    email = request.email
    mfa_code = request.mfa_code
    remember_for_day = getattr(request, 'remember_for_day', False)  # Get remember me flag
    
    if not email or not mfa_code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email and MFA code are required"
        )
    
    user = get_user_by_email(email)
    if not user:
        logger.warning(f"MFA verification for non-existent user: {email}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Get stored MFA code and expiry
    stored_code = user.get("mfa_code")
    expires_at = user.get("mfa_code_expires")
    
    # Convert string to datetime if needed
    if expires_at and isinstance(expires_at, str):
        try:
            expires_at = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
        except ValueError:
            expires_at = None
    
    # Validate code
    is_valid, error_message = mfa_service.is_code_valid(stored_code, mfa_code, expires_at)
    
    if not is_valid:
        logger.warning(f"Invalid MFA code for user: {email}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_message
        )
    
    # Clear MFA code after successful verification
    clear_user_mfa_code(user["_id"])
    
    # ✅ If "Remember Me" is checked, store MFA session
    if remember_for_day:
        mfa_session_token = secrets.token_urlsafe(32)
        mfa_verified_at = datetime.utcnow()
        
        # Update user with MFA session info
        update_user_mfa_session(
            user_id=user["_id"],
            mfa_verified_at=mfa_verified_at,
            mfa_session_token=mfa_session_token
        )
        
        logger.info(f"MFA session created for user: {user['email']} (valid for 24 hours)")
    
    # Create access token
    access_token = create_access_token(data={"sub": user["email"]})
    
    # ✅ CRITICAL: Validate the token immediately after creation
    token_info = get_token_expiry_info(access_token)
    
    # Log only errors or warnings, not successful validations
    if not token_info['valid']:
        logger.error(f"CRITICAL: Token invalid immediately after creation for user: {user['email']}")
    
    # Log successful MFA verification
    logger.info(f"MFA verification successful for user: {user['email']}")
    
    response_data = {
        "access_token": access_token,
        "token_type": "bearer",
        "email": user["email"],
        "message": "Login successful"
    }
    
    if remember_for_day:
        response_data["mfa_session_token"] = mfa_session_token
        response_data["expires_in"] = 86400  # 24 hours in seconds
    
    return response_data

# -------------------------------
# Check MFA Session Endpoint - NEW
# -------------------------------
@router.post("/check-mfa-session")
async def check_mfa_session(request: MFASessionCheckRequest):
    """
    Check if MFA session is still valid (within 24 hours).
    """
    email = request.email
    mfa_session_token = request.mfa_session_token
    
    if not email:
        return {"mfa_required": True, "mfa_valid": False}
    
    user = get_user_by_email(email)
    if not user:
        return {"mfa_required": True, "mfa_valid": False}
    
    # Check if MFA was verified within last 24 hours
    mfa_verified_at = user.get("mfa_verified_at")
    stored_session_token = user.get("mfa_session_token")
    
    if mfa_verified_at and stored_session_token:
        # Convert string to datetime if needed
        if isinstance(mfa_verified_at, str):
            try:
                mfa_verified_at = datetime.fromisoformat(mfa_verified_at.replace('Z', '+00:00'))
            except ValueError:
                mfa_verified_at = None
        
        # Check if within 24 hours and token matches
        if mfa_verified_at and (datetime.utcnow() - mfa_verified_at) < timedelta(hours=24):
            if mfa_session_token and mfa_session_token == stored_session_token:
                return {"mfa_required": False, "mfa_valid": True}
            elif not mfa_session_token:
                # Session exists but no token provided
                return {"mfa_required": False, "mfa_valid": True, "session_exists": True}
    
    return {"mfa_required": True, "mfa_valid": False}

# -------------------------------
# Forgot Password Endpoint
# -------------------------------
@router.post("/forgot-password", response_model=ForgotPasswordResponse)
async def forgot_password(request: ForgotPasswordRequest):
    """
    Initiate password reset process.
    Always returns success to prevent email enumeration attacks.
    """
    logger.debug(f"Forgot password requested for: {request.email}")
    
    user = get_user_by_email(request.email)
    
    # Always return success to prevent email enumeration
    if not user:
        logger.debug(f"Password reset requested for non-existent email: {request.email}")
        return ForgotPasswordResponse(
            message="If the email exists, a reset link has been sent"
        )
    
    # Generate reset token
    reset_token = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(hours=1)  # Token valid for 1 hour
    
    # Save token to database
    token_created = create_password_reset_token(
        token=reset_token,
        user_id=user["_id"],
        expires_at=expires_at
    )
    
    if not token_created:
        logger.error(f"Failed to create password reset token for user: {user['email']}")
        # Still return success for security
        return ForgotPasswordResponse(
            message="If the email exists, a reset link has been sent"
        )
    
    # Send reset email
    try:
        result = await send_reset_email(user["email"], reset_token, user["email"])
        logger.info(f"Password reset email sent to: {user['email']}")
    except Exception as e:
        logger.error(f"Failed to send reset email to {user['email']}: {str(e)}")
        # Still return success for security
    
    return ForgotPasswordResponse(
        message="If the email exists, a reset link has been sent"
    )

# -------------------------------
# Reset Password Endpoint
# -------------------------------
@router.post("/reset-password", response_model=ResetPasswordResponse)
async def reset_password(request: ResetPasswordRequest):
    """
    Reset user password using a valid reset token.
    """
    # Find valid token
    token_record = get_valid_password_reset_token(request.token)
    
    if not token_record:
        logger.warning(f"Invalid password reset token used")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired reset token"
        )
    
    # Update user password
    password_updated = update_user_password(
        user_id=token_record["user_id"],
        new_password=request.new_password
    )
    
    if not password_updated:
        logger.error(f"Failed to reset password for user ID: {token_record['user_id']}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to reset password"
        )
    
    # Mark token as used
    mark_password_reset_token_used(request.token)
    
    logger.info(f"Password reset successful for user ID: {token_record['user_id']}")
    
    return ResetPasswordResponse(
        message="Password reset successfully"
    )

# -------------------------------
# Other MFA endpoints (setup, disable, status)
# -------------------------------
@router.post("/setup-mfa")
async def setup_mfa(request: MFASetupRequest, background_tasks: BackgroundTasks):
    """
    Enable MFA for user account.
    """
    email = request.email
    
    if not email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is required"
        )
    
    user = get_user_by_email(email)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Check if MFA is already enabled
    if user.get("mfa_enabled", False):
        logger.warning(f"MFA setup requested but already enabled for: {email}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already enabled for this account"
        )
    
    # Update MFA settings
    mfa_email = request.mfa_email or user["email"]
    update_data = {
        "mfa_enabled": True,
        "mfa_email": mfa_email,
        "mfa_setup_completed": True,
        "updated_at": datetime.utcnow()
    }
    
    success = update_user_mfa_status(user["_id"], update_data)
    
    if not success:
        logger.error(f"Failed to enable MFA for user: {email}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to enable MFA"
        )
    
    # Send setup confirmation email
    background_tasks.add_task(
        send_mfa_setup_email,
        user_email=user["email"]
    )
    
    logger.info(f"MFA enabled for user: {user['email']}")
    
    return {
        "message": "MFA enabled successfully",
        "mfa_email": mfa_email,
        "setup_completed": True
    }

@router.post("/disable-mfa")
async def disable_mfa(request: Dict[str, str]):
    """
    Disable MFA for user account.
    """
    email = request.get("email")
    if not email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is required"
        )
    
    user = get_user_by_email(email)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Check if MFA is already disabled
    if not user.get("mfa_enabled", False):
        logger.warning(f"MFA disable requested but already disabled for: {email}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already disabled for this account"
        )
    
    # Disable MFA and clear session
    update_data = {
        "mfa_enabled": False,
        "mfa_code": None,
        "mfa_code_expires": None,
        "mfa_verified_at": None,
        "mfa_session_token": None,
        "updated_at": datetime.utcnow()
    }
    
    success = update_user_mfa_status(user["_id"], update_data)
    
    if not success:
        logger.error(f"Failed to disable MFA for user: {email}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to disable MFA"
        )
    
    logger.info(f"MFA disabled for user: {user['email']}")
    
    return {"message": "MFA disabled successfully"}

@router.get("/mfa-status")
async def get_mfa_status(email: str):
    """
    Get MFA status for a user.
    """
    user = get_user_by_email(email)
    if not user:
        logger.warning(f"MFA status requested for non-existent user: {email}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return {
        "mfa_enabled": user.get("mfa_enabled", False),
        "mfa_email": user.get("mfa_email"),
        "mfa_setup_completed": user.get("mfa_setup_completed", False)
    }

# -------------------------------
# Helper Functions
# -------------------------------
async def send_mfa_code_to_user(user: Dict[str, Any]):
    """
    Generate and send MFA code to user.
    This function is meant to be run in the background.
    """
    # Generate new MFA code
    mfa_code = mfa_service.generate_mfa_code()
    expires_at = mfa_service.get_code_expiry()
    
    # Update user with new code
    update_user_mfa_code(
        user_id=user["_id"],
        mfa_code=mfa_code,
        expires_at=expires_at
    )
    
    # Determine which email to use
    mfa_email = user.get("mfa_email") or user["email"]
    
    try:
        # Send MFA email
        await send_mfa_email(
            to_email=mfa_email,
            mfa_code=mfa_code,
            user_email=user["email"]
        )
        logger.debug(f"MFA code sent to {mfa_email} for user {user['email']}")
    except Exception as e:
        logger.error(f"Failed to send MFA email to {mfa_email}: {e}")
        # Don't raise error to prevent email enumeration
        # The code is still saved, user can request resend